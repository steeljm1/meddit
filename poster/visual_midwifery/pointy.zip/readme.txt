Copyright 2007-2008 James Beardmore.  Personal, non profit use of this font is free.  For commercial licensing, please contact me: contact@pointydesign.com.

Thanks and enjoy!

James Beardmore

Pointy Design
http://www.pointydesign.com