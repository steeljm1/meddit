<?php

class ModelView extends DataObject {

    // Database Structure
    private static $db = array(
        'Title' => 'Varchar',
        'Step' => 'Int'
    );

    private static $has_one = array(
        'MainCategories' => 'MainCategories',
        'Image' => 'Image'
    );
    
    private static $has_many = array(
        'ModelColour' => 'ModelColour'
    );
    
	// CMS Display
    public static $summary_fields = array (
        'Title' => 'Title',
        'Step' => 'Step',
        'Image.CMSThumbnail' => 'Image'
    );
	
    public function getThumbnail() {
        if($this->Image())
            return $this->Image()->CMSThumbnail();
    }

		//Form validation
	public function getCMSValidator() {
		return new RequiredFields('Title', 'Step', 'Image');
	}
	
    // API Visibility
    public static $api_access = array(
        'view' => array('LastUpdated', 'Title', 'Step', 'ImageUrl')
    ); 
	
	public function getImageUrl(){
		return 'http://' . $_SERVER['HTTP_HOST'] . $this->Image()->URL;
	}

    public function getLastUpdated() {
        return strtotime($this->LastEdited);
    }
	
	// Lecturer Permissions
    function canView($member = false) {
        return true;
    }	
	
	public function canEdit($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}
	
	public function canCreate($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}

	function canDelete($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');			
		}		
	}
}