<?php

class ContentField extends DataObject{

	// Database Structure
    private static $db = array(
		'Notes' => 'Text'
    );

    private static $has_one = array(
        'ContentCategory' => 'ContentCategory',
        'Image' => 'Image'
    );  

	// CMS Display
    private static $summary_fields = array(
            'Notes' => 'Notes',
            'Image.CMSThumbnail' => 'Image'
    );
	
    public function getThumbnail() {
        if($this->Image())
            return $this->Image()->CMSThumbnail();
    }	
	
    // API Visibility
    public static $api_access = array(
        'view' => array('LastUpdated', 'Notes', 'ImageUrl')
    ); 
	 
	public function getImageUrl(){
		return 'http://' . $_SERVER['HTTP_HOST'] . $this->Image()->URL;
	}
	
    public function getLastUpdated() {
        return strtotime($this->LastEdited);
    }
	
	//Form validation
	public function getCMSValidator() {
		return new RequiredFields('Notes', 'Image');
	}
	
	// Lecturer Permissions
	function canView($member = false) {
        return true;
    }
	
	public function canEdit($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}	
	
	public function canCreate($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}

	function canDelete($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');			
		}		
	}
}