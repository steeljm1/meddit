tinyMCE.addI18n('nl.tinymce_ssmacron', {
  insertmacron: 'Een macron toevoegen'
});
