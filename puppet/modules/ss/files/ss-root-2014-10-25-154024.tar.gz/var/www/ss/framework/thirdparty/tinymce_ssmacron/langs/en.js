tinyMCE.addI18n('en.tinymce_ssmacron', {
	insertmacron: 'Insert a macron'
});