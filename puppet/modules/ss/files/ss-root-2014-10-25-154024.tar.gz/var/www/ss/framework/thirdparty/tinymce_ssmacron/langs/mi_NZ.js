tinyMCE.addI18n('mi_NZ.tinymce_ssmacron', {
	insertmacron: 'T\u0101urua he tohut\u014D'
});