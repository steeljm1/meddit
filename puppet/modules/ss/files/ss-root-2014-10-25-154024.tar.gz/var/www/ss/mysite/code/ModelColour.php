<?php

class ModelColour extends DataObject{

	//Database Structure
    private static $db = array(
		'Name' => 'Varchar',	
		'BgColor' => 'Text'
    );

    private static $has_one = array(
            'ModelView' => 'ModelView'
    );

	// CMS  display
    private static $summary_fields = array(
            'Name' => 'Name',
            'BgColor' => 'BgColor',
    );
	
    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->addFieldToTab(
            'Root.Main', 
            new ColorField('BgColor', 'Background color')
        );

        return $fields;
    }

    public function getLastUpdated()
    {
        return strtotime($this->LastEdited);
    }	

	//Form validation
	public function getCMSValidator() {
		return new RequiredFields('Name', 'BgColor');
	}
	
	
	// API Visibility
    public static $api_access = array(
        'view' => array('LastUpdated', 'Name', 'BgColor')
    ); 
   
	// Lecturer Permissions
    function canView($member = false) {
        return true;
    }
	
	public function canEdit($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}
	
	public function canCreate($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}

	function canDelete($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');			
		}		
	}
}