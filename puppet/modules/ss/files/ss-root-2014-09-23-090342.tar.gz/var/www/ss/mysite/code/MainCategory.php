<?php

class MainCategories extends DataObject {

    private static $db = array(
            'Title' => 'Varchar'
    );

    private static $has_many = array(
            'ContentCategory' => 'ContentCategory',
            'ModelView' => 'ModelView'
    );

    private static $summary_fields = array(
            'Title' => 'Title'
    );

    function canView($member = false) {
        return true;
    }
 
    // for every object
    public static $api_access = array(
        'view' => array('LastUpdated', 'Title')
    ); 
	
    public function getLastUpdated() {
        return strtotime($this->LastEdited);
    }
	
	public function canEdit($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}
}