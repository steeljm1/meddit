<?php

global $lang;

$lang['en_US']['i18nOtherModule']['LEGACYTHEME'] = 'Legacy translation';