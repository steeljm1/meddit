<?php

class ContentCategory extends DataObject {


	// Database structure
	private static $db = array(
		'Title' => 'Varchar'
	);
	
	private static $has_one = array(
		'MainCategories' => 'MainCategories'
	);	
	
	private static $has_many = array(
		'ContentField' => 'ContentField'
	);
	
	// API Visibility
	static $api_access = true;	

	private static $summary_fields = array(
		'Title' => 'Title'
	);
	
	//Form validation
	public function getCMSValidator() {
		return new RequiredFields('Title');
	}
	
	// Lecturer permissions
	function canView($member = false) {
		return true;
	}	
	
	public function canEdit($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}
	
	public function canCreate($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}

	function canDelete($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');			
		}		
	}
}
