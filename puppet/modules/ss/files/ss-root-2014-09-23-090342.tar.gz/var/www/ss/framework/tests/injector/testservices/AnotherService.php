<?php

class AnotherService
{
	public $filters = array();
}