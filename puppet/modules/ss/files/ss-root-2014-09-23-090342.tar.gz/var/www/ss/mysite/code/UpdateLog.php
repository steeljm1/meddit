<?php

class UpdateLog extends DataObject {

	private static $db = array(
		'Description' => 'Varchar'
	);
	
    private static $summary_fields = array(
		'Description' => 'Description',
		'LastUpdated' => 'LastUpdated'
    );
	
	public function getLastUpdated() {
        return strtotime($this->LastEdited);
    }
	
	public static $api_access = array(
        'view' => array('LastUpdated')
    ); 
	
	function canView($member = false) {
        return true;
    }
	
	public function canEdit($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}	
	
	public function canCreate($member = false) {
		if(!$member) {
			$member = Member::currentUser();
			return $member->inGroup('Lecturer');
		}
	}
}
