<?php
/**
 * This is the config file of the SilverStripe ColorPicker Form-Element
 * @author Roman Schmid, AKA banal
 * 
 * ColorPicker jQuery widget/plugin by http://www.eyecon.ro/colorpicker/
 */
