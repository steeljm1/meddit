<?php
 
class CategoryModelAdminExtension extends ModelAdmin
{
    private static $menu_priority = 1;
    private static $url_segment = 'MainCategory';
    private static $managed_models = array('MainCategories', 'UpdateLog');
    private static $menu_title = 'CMS';
	
}